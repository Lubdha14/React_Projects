import React from 'react'
//card is the component in data whole data we will get
const Card = ({data}) => {
     console.log(data);
//Define the readmore function
// window.open - url in new tab
     const readMore = (url) =>{
        //to open the url in new tab
        window.open(url)
     }
     
  return (
    //data.map(parameters) - CREATE THE NEW ARRAY AND ITERATE ON ARRAY VALUE (data seperate krta hai)
    <div className='cardContainer'>
       {data.map((curItem,index)=>{
        if(!curItem.urlToImage){
            return null
        }
        //curItem.urlToImage - news ki image
        else{
            return(
            <div className='card'>
                <img src={curItem.urlToImage}/>
                <div className='content'>
                    <a className='title' onClick={()=>window.open(curItem.url)}>{curItem.title}</a>
                    {/* //read more -- when click we can be redirected in new tab */}
                    <p>{curItem.description}</p>
                    
                    <button onClick={()=>window.open(curItem.url)}>Read More</button>
                </div>
            </div>
        )
        }   
    })}
    </div>
  )
}
export default Card
// 