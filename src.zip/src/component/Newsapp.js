import React, { useEffect, useState } from 'react'
import Card from './Card'

const Newsapp = () => {
    // at the first whenever the user search he will get this news
    const [search, setSearch] = useState("Maharashtra");
    const [newsData, setNewsData] = useState(null)
    // create the variable API_KEY and store api key in it
    const API_KEY = "9c3ed8ee95884dec979460a60f96675b";
// create the function getDatabase---- async:- to resolve the promise
    // promise 1. if i willl get Date
    //         2.Data will be resolved
    //         3.Data will be in prnding state
        const getData = async() =>{
        // wait till the data comes therefore await
        // from news api website take the api link
        const response = await fetch(`https://newsapi.org/v2/everything?q=${search}&apiKey=${API_KEY}`);
         //data converted into JSON and stored in jsonData
         //await- wait till the datta is converted into jsonData
        const jsonData = await response.json();
        console.log(jsonData.articles);
        let dt = jsonData.articles.slice(0,10)
        setNewsData(dt)
        
    }
   //whenn first time our website run it should display something so we need to display the content so use use efect

//use effect hook run after every component is render
//it take call back function 
//get data-- show data when website run (array dependecy) -- [] by empty brackets----after refresh it call the fuction only once
    useEffect(()=>{
        getData()
    },[])

    const handleInput = (e) =>{
        console.log(e.target.value);
        setSearch(e.target.value)
        
    }
    //define the function :- by (event) get the value,  data send to : setSerch,
    const userInput = (event) =>{
        setSearch(event.target.value)
    }

  return (
    <div>
        <nav>
            <div>
                <h1>News Hub!!! </h1>
            </div>
            <ul style={{display:"flex", gap:"11px"}}>
                <a style={{fontWeight:600, fontSize:"17px"}}>TopStory</a>
                <a style={{fontWeight:600, fontSize:"17px"}}>Trending</a>

            </ul>
            <div className='searchBar'>
                <input type='text' placeholder='Search News' value={search} onChange={handleInput}/>
                <button onClick={getData}>Search</button>
            </div>
        </nav>
        <div>
            <p className='head'>"Every headline, in your hand.!!!"</p>
        </div>
        {/* //onclick event - userInput  */}
        <div className='categoryBtn'>
            <button onClick={userInput} value="sports">Sports</button>
            <button onClick={userInput} value="Education">Education</button>
            <button onClick={userInput} value="politics">Politics</button>
            <button onClick={userInput} value="entertainment">Entertainment</button>
            <button onClick={userInput} value="health">Health</button>
            <button onClick={userInput} value="fitness">Fitness</button>
        </div>
{/* //if news data has the data then return data else null */}
        <div>
        {newsData?  <Card data={newsData}/> : null}
            
        </div>
    </div>
  )
}

export default Newsapp

//news api website link- register with email then we will get api key 