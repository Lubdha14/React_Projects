import logo from './logo.svg';
import './App.css';
import Newsapp from './component/Newsapp';
function App() {
  return (
    <Newsapp />
  );
}

export default App;
